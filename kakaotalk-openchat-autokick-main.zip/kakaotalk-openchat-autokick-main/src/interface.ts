export interface ConfigInterface {
  email: string;
  password: string;
  deviceUuid: string;
  deviceName: string;
}
